/*
 * Wazuh app - React component for build q queries.
 * Copyright (C) 2015-2020 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
import React, { Component } from 'react';
import {
  EuiButtonEmpty,
  EuiOverlayMask,
  EuiModal,
  EuiModalHeader,
  EuiModalBody,
  EuiModalHeaderTitle
} from '@elastic/eui';
import { connect } from 'react-redux';
import { showExploreAgentModalGlobal } from '../../redux/actions/appStateActions';
import store from '../../redux/store';
import { AgentSelectionTable } from '../../controllers/overview/components/overview-actions/agents-selection-table';
import chrome from 'ui/chrome';
import { getServices } from '../../../../../src/plugins/discover/public/kibana_services';
import { WAZUH_ALERTS_PATTERN } from '../../../util/constants';
import { AppState } from '../../react-services/app-state';

class WzAgentSelector extends Component {
  constructor(props) {
    super(props);
    this.state = {
   
    };
    this.store = store;
  }

  async componentDidMount() {
    const $injector = await chrome.dangerouslyGetActiveInjector();
    this.route = $injector.get('$route');
    this.location = $injector.get('$location');
  }

  closeAgentModal(){
    store.dispatch(showExploreAgentModalGlobal(false));
  }

  agentTableSearch(agentIdList){
    this.closeAgentModal();
    if(window.location.href.includes("/agents?")){
      this.location.search('agent', store.getState().appStateReducers.currentAgentData.id ? String(store.getState().appStateReducers.currentAgentData.id):null);
      this.route.reload();
      return;
    }
    this.location.search('agentId', store.getState().appStateReducers.currentAgentData.id ? String(store.getState().appStateReducers.currentAgentData.id):null);

    const { filterManager } = getServices();
    if (agentIdList && agentIdList.length) {
      if (agentIdList.length === 1) {
        const currentAppliedFilters = filterManager.filters;
        const agentFilters = currentAppliedFilters.filter(x => {
          return x.meta.key !== 'agent.id';
        });
        const filter = {
          "meta": {
            "alias": null,
            "disabled": false,
            "key": "agent.id",
            "negate": false,
            "params": { "query": agentIdList[0] },
            "type": "phrase",
            "index": AppState.getCurrentPattern() || WAZUH_ALERTS_PATTERN
          },
          "query": {
            "match": {
              'agent.id': {
                query: agentIdList[0],
                type: 'phrase'
              }
            }
          },
          "$state": { "store": "appState", "isImplicit": true},
        };
        agentFilters.push(filter);
        filterManager.setFilters(agentFilters);
      }
    }
  }

  removeAgentsFilter(shouldUpdate){
    this.closeAgentModal();
    if(window.location.href.includes("/agents?")){
      window.location.href = "#/agents-preview"
      this.route.reload();
      return;
    }
    const { filterManager } = getServices();
    const currentAppliedFilters = filterManager.filters;
    const agentFilters = currentAppliedFilters.filter(x => {
      return x.meta.key === 'agent.id';
    });
    agentFilters.map(x => {
      filterManager.removeFilter(x);
    });
    this.closeAgentModal();
  }

  getSelectedAgents(){
    const selectedAgents = {};
    const agentId = store.getState().appStateReducers.currentAgentData.id;
    if(agentId)
      selectedAgents[agentId] = true;
    return selectedAgents;
  }

  render() {
    let modal = (<></>);

    if (this.props.state.showExploreAgentModalGlobal) {
      modal = (
        <EuiOverlayMask onClick={() => this.closeAgentModal()}>
          <EuiModal
            className="wz-select-agent-modal"
            onClose={() => this.closeAgentModal()}
            initialFocus="[name=popswitch]"
          >
            <EuiModalHeader>
              <EuiModalHeaderTitle>Explore agent</EuiModalHeaderTitle>
            </EuiModalHeader>

            <EuiModalBody>
              <AgentSelectionTable
                updateAgentSearch={agentsIdList => this.agentTableSearch(agentsIdList)}
                removeAgentsFilter={(shouldUpdate) => this.removeAgentsFilter(shouldUpdate)}
                selectedAgents={this.getSelectedAgents()}
              ></AgentSelectionTable>
            </EuiModalBody>
          </EuiModal>
        </EuiOverlayMask>
      );
    }
    return modal;
  }
}

const mapStateToProps = state => {
  return {
    state: state.appStateReducers
  };
};

export default connect(
  mapStateToProps,
  null
)(WzAgentSelector);
